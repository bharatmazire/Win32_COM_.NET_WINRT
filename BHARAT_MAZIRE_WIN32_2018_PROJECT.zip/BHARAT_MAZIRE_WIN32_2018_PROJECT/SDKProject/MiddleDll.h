extern "C" HRESULT SidesOfTriangle(double x1, double y1, double x2, double y2, double x3, double y3, int* pType);
extern "C" HRESULT AngleOfTriangle(double a, double b, double c, int* pType);

