extern "C" HRESULT ChemistryCalculation(int , double , double , double *);
