extern "C" int ChemistryCalculation(int , double , double , double *);
